#ifndef _BIBLIOTECA_H

#define _BIBLIOTECA_H

double suma(double a, double b );
double resta(double a, double b);
double multi(double a, double b);
double divis(double a, double b);
double sqrt_lib(double c);
double cos_lib(double c);

#endif

